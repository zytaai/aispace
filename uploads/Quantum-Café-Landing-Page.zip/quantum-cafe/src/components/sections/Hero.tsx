"use client";

import Link from "next/link";
import { motion } from "framer-motion";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden py-20 px-4">
      {/* Spotlight Effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="spotlight"></div>
      </div>

      {/* LED Tube Light Effect */}
      <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-white/5 to-transparent"></div>

      <motion.div
        className="z-10 text-center max-w-5xl px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tighter mb-6">
          <span className="bg-clip-text text-transparent bg-gradient-to-b from-white to-white/80">
            Brew Intelligence with<br /> Q-Brew AI Assistant
          </span>
        </h1>

        <p className="text-lg md:text-xl text-quantum-secondary max-w-3xl mx-auto mb-10">
          Powered by LLaMA 4.0 Scout — designed for quantum learners.
          <br />
          <span className="text-quantum-accent">No login, no user data — full privacy.</span>
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            href="#chat"
            className="px-6 py-3 rounded-md button-gradient font-medium text-sm md:text-base min-w-[160px]"
          >
            Start Chatting
          </Link>
          <Link
            href="#beta"
            className="px-6 py-3 rounded-md button-ghost font-medium text-sm md:text-base min-w-[160px]"
          >
            Join Beta
          </Link>
        </div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-12 left-1/2 -translate-x-1/2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
      >
        <motion.div
          className="w-6 h-10 border-2 border-white/20 rounded-full flex justify-center"
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
        >
          <motion.div
            className="w-1.5 h-1.5 bg-white/80 rounded-full mt-2"
            animate={{ opacity: [1, 0.3, 1], y: [0, 8, 0] }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
          />
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Hero;
