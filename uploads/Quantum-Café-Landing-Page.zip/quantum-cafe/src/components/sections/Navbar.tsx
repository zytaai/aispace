"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 py-4 px-6 bg-black/40 backdrop-blur-lg border-b border-white/5">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 z-10">
          <svg
            viewBox="0 0 24 24"
            className="w-8 h-8"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M12 2L2 7L12 12L22 7L12 2Z"
              fill="currentColor"
              fillOpacity="0.7"
            />
            <path
              d="M2 17L12 22L22 17"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M2 12L12 17L22 12"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <span className="text-xl font-bold">Quantum Café</span>
        </Link>

        {/* Center Navigation - Desktop */}
        <div className="absolute left-1/2 -translate-x-1/2 hidden md:flex">
          <div className="flex items-center bg-black/60 backdrop-blur-lg rounded-full px-4 py-2 border border-white/10">
            <Link href="/" className="text-sm text-white hover:text-white transition-colors px-4">
              Home
            </Link>
            <Link href="#features" className="text-sm text-white/70 hover:text-white transition-colors px-4">
              Features
            </Link>
            <Link href="#flashcards" className="text-sm text-white/70 hover:text-white transition-colors px-4">
              Flashcards
            </Link>
            <Link href="#contact" className="text-sm text-white/70 hover:text-white transition-colors px-4">
              About
            </Link>
          </div>
        </div>

        {/* Right Side Buttons - Desktop */}
        <div className="hidden md:flex items-center gap-3 z-10">
          <Link
            href="#chat"
            className="px-4 py-2 text-sm rounded-md button-ghost"
          >
            Learn More
          </Link>
          <Link
            href="#chat"
            className="px-4 py-2 text-sm rounded-md button-gradient font-medium"
          >
            Try It Now
          </Link>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden flex items-center z-10"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 p-4 bg-black/90 backdrop-blur-lg mt-px shadow-lg">
          <div className="flex flex-col space-y-4 py-2">
            <Link
              href="/"
              className="text-sm font-medium"
              onClick={() => setIsOpen(false)}
            >
              Home
            </Link>
            <Link
              href="#features"
              className="text-sm font-medium"
              onClick={() => setIsOpen(false)}
            >
              Features
            </Link>
            <Link
              href="#flashcards"
              className="text-sm font-medium"
              onClick={() => setIsOpen(false)}
            >
              Flashcards
            </Link>
            <Link
              href="#contact"
              className="text-sm font-medium"
              onClick={() => setIsOpen(false)}
            >
              About
            </Link>

            <div className="flex flex-col space-y-3 pt-2">
              <Link
                href="#chat"
                className="px-4 py-2 text-sm rounded-md button-ghost text-center"
                onClick={() => setIsOpen(false)}
              >
                Learn More
              </Link>
              <Link
                href="#chat"
                className="px-4 py-2 text-sm rounded-md button-gradient font-medium text-center"
                onClick={() => setIsOpen(false)}
              >
                Try It Now
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
