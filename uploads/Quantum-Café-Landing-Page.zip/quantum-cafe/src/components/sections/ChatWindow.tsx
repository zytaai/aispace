"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { Send, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

type Message = {
  role: "user" | "assistant";
  content: string;
  id: string;
};

export default function ChatWindow() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const API_KEY = "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";

  // Generate unique IDs for messages
  const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
  };

  const scrollToBottom = useCallback(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, []);

  // Effect to scroll to bottom when messages change
  useEffect(() => {
    // Only scroll if there are messages
    if (messages.length > 0) {
      scrollToBottom();
    }
  }, [messages, scrollToBottom]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: Message = {
      role: "user",
      content: input,
      id: generateId(),
    };

    // Update messages state with user message
    setMessages((prev) => [...prev, userMessage]);
    setInput("");  // Clear input field
    setIsLoading(true);

    // Preserve scroll position
    const scrollPosition = messagesContainerRef.current?.scrollTop;

    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "openrouter/llama-4.0-scout",
          messages: [...messages, userMessage].map(({role, content}) => ({role, content})),
        }),
      });

      const data = await response.json();

      if (data.choices?.[0]) {
        const assistantMessage: Message = {
          role: "assistant",
          content: data.choices[0].message.content,
          id: generateId(),
        };
        setMessages((prev) => [...prev, assistantMessage]);
      } else {
        throw new Error("Invalid response from API");
      }
    } catch (error) {
      console.error("Error calling the API:", error);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "I'm sorry, I encountered an error. Please try again later.",
          id: generateId(),
        },
      ]);
    } finally {
      setIsLoading(false);

      // Restore scroll position + small delay to ensure DOM update
      setTimeout(() => {
        if (messagesContainerRef.current && scrollPosition) {
          messagesContainerRef.current.scrollTop = scrollPosition;
        }
        scrollToBottom();
      }, 100);
    }
  };

  return (
    <section id="chat" className="py-16 px-4">
      <motion.div
        className="mac-window max-w-5xl mx-auto shadow-2xl"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        viewport={{ once: true }}
      >
        <div className="mac-window-header">
          <div className="mac-window-buttons">
            <div className="mac-dot mac-dot-red" />
            <div className="mac-dot mac-dot-yellow" />
            <div className="mac-dot mac-dot-green" />
          </div>
          <div className="flex justify-center w-full text-sm font-medium text-gray-400">
            Q-Brew AI v1.0
          </div>
        </div>

        <div className="p-4 md:p-6 flex flex-col h-[600px]">
          {/* Chat messages */}
          <div
            ref={messagesContainerRef}
            className="flex-1 overflow-y-auto mb-4 font-sans scrollbar-thin pr-2"
            style={{ scrollBehavior: 'smooth' }}
          >
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6">
                <div className="mb-6">
                  <svg viewBox="0 0 24 24" className="w-12 h-12 mx-auto mb-4 text-white/80">
                    <path
                      d="M12 2L2 7L12 12L22 7L12 2Z"
                      fill="currentColor"
                      fillOpacity="0.7"
                    />
                    <path
                      d="M2 17L12 22L22 17"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M2 12L12 17L22 12"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
                <h2 className="text-xl font-medium mb-2">
                  Unleash AI with Q-Brew: Chatbot-Driven
                </h2>
                <p className="text-quantum-secondary text-sm max-w-md">
                  Ask anything about quantum computing. Powered by LLaMA 4.0 Scout with no login or data tracking.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${
                      message.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[85%] px-4 py-3 rounded-lg ${
                        message.role === "user"
                          ? "bg-quantum-accent/10 text-white rounded-br-none"
                          : "bg-quantum-card text-white rounded-bl-none"
                      }`}
                    >
                      <p className="text-sm md:text-base whitespace-pre-wrap">{message.content}</p>
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="max-w-[85%] px-4 py-3 rounded-lg bg-quantum-card text-white rounded-bl-none">
                      <div className="flex items-center space-x-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-sm">Q-Brew is thinking...</span>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} className="h-2" />
              </div>
            )}
          </div>

          {/* Input form */}
          <form onSubmit={handleSubmit} className="flex items-center gap-2 relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about quantum computing..."
              className="flex-1 bg-quantum-card border border-white/10 text-white rounded-md px-4 py-3 focus:outline-none focus:ring-1 focus:ring-white/30"
              disabled={isLoading}
              autoComplete="off"
            />
            <button
              type="submit"
              className="p-3 rounded-md button-ghost"
              disabled={isLoading}
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </button>
          </form>
        </div>
      </motion.div>
    </section>
  );
}
