"use client";

import { useState } from "react";
import { motion } from "framer-motion";

type FlashcardProps = {
  title: string;
  content: string;
};

const Flashcard = ({ title, content }: FlashcardProps) => {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div
      className="h-[250px] w-full cursor-pointer perspective"
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <motion.div
        className="relative w-full h-full transform-style-3d"
        initial={false}
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Front of card */}
        <div className="absolute inset-0 backface-hidden rounded-lg glass border-2 border-white/10 p-6 flex flex-col items-center justify-center text-center">
          <div className="h-12 w-12 rounded-full bg-white/10 flex items-center justify-center mb-4">
            <svg
              viewBox="0 0 24 24"
              className="w-6 h-6"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12 6V12L16 14"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              />
              <circle
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="2"
              />
            </svg>
          </div>
          <h3 className="text-lg font-medium mb-2">{title}</h3>
          <p className="text-quantum-secondary text-sm">Click to flip</p>
        </div>

        {/* Back of card */}
        <div className="absolute inset-0 backface-hidden rounded-lg glass border-2 border-white/10 p-6 flex flex-col items-center justify-center text-center rotateY-180">
          <p className="text-sm leading-relaxed text-quantum-secondary overflow-y-auto max-h-full">
            {content}
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default function Flashcards() {
  const cards = [
    {
      title: "What is a Qubit?",
      content:
        "A qubit (quantum bit) is the fundamental unit of quantum information. Unlike classical bits that can only be 0 or 1, qubits can exist in a superposition of both states simultaneously. This property enables quantum computers to process vast amounts of information in parallel.",
    },
    {
      title: "Superposition vs. Entanglement",
      content:
        "Superposition allows quantum particles to exist in multiple states at once. Entanglement is a phenomenon where quantum particles become correlated in such a way that the quantum state of each cannot be described independently. Einstein called entanglement 'spooky action at a distance.'",
    },
    {
      title: "Quantum Gates 101",
      content:
        "Quantum gates are the building blocks of quantum circuits. They manipulate qubits to perform operations. Common gates include: Hadamard (creates superposition), Pauli-X (like classical NOT gate), CNOT (creates entanglement), and Toffoli (universal for quantum computation).",
    },
  ];

  return (
    <section id="flashcards" className="py-24 px-4 relative">
      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Quantum Flashcards
          </h2>
          <p className="text-quantum-secondary max-w-2xl mx-auto">
            Learn quantum concepts, one card at a time. Flip the cards to reveal
            explanations about fundamental quantum computing principles.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {cards.map((card, index) => (
            <motion.div
              key={`card-${index}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Flashcard title={card.title} content={card.content} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
